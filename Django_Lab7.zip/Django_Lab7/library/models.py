from django.db import models


class Author(models.Model):

    first_name = models.CharField(max_length=50)

    last_name = models.CharField(max_length=50)

    birth_year = models.IntegerField()

    class Meta:
        ordering = ['last_name']
        verbose_name = 'Автор'
        verbose_name_plural = 'Автори'

    def __str__(self):
        return f"{self.first_name} {self.last_name}"


class Genre(models.Model):

    title = models.CharField(
        max_length=50,
        unique=True
    )

    description = models.TextField()

    color = models.CharField(
        max_length=20
    )

    class Meta:
        ordering = ['title']
        verbose_name = 'Жанр'
        verbose_name_plural = 'Жанри'

    def __str__(self):
        return self.title


class Book(models.Model):

    title = models.CharField(
        max_length=100
    )

    isbn = models.CharField(
        max_length=13,
        unique=True
    )

    pages = models.IntegerField(
    default=100
)

    year = models.IntegerField()

    author = models.ForeignKey(
        Author,
        on_delete=models.CASCADE
    )

    genres = models.ManyToManyField(
        Genre
    )

    class Meta:
        ordering = ['title']
        verbose_name = 'Книга'
        verbose_name_plural = 'Книги'

    def __str__(self):
        return self.title


class Reader(models.Model):

    full_name = models.CharField(
        max_length=100
    )

    email = models.EmailField(
        unique=True
    )

    phone = models.CharField(
        max_length=20
    )

    class Meta:
        ordering = ['full_name']
        verbose_name = 'Читач'
        verbose_name_plural = 'Читачі'

    def __str__(self):
        return self.full_name


class ReaderProfile(models.Model):

    reader = models.OneToOneField(
        Reader,
        on_delete=models.CASCADE
    )

    address = models.CharField(
        max_length=200
    )

    notes = models.TextField()

    registration_date = models.DateField(
        auto_now_add=True
    )

    class Meta:
        ordering = ['reader']
        verbose_name = 'Профіль'
        verbose_name_plural = 'Профілі'

    def __str__(self):
        return self.reader.full_name

