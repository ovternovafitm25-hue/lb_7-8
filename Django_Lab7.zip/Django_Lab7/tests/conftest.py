import pytest

from library.models import (
    Author,
    Genre,
    Book
)


@pytest.fixture
def author():

    return Author.objects.create(
        first_name='Taras',
        last_name='Shevchenko',
        birth_year=1814
    )


@pytest.fixture
def genre():

    return Genre.objects.create(
        title='Novel',
        description='Novel genre',
        color='Blue'
    )
