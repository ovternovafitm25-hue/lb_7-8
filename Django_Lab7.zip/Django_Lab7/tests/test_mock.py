from unittest.mock import patch


@patch('library.models.Author.save')
def test_mock_save(mock_save):

    mock_save()

    mock_save.assert_called_once()
