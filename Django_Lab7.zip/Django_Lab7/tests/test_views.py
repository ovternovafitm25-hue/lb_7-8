import pytest
from django.test import Client


@pytest.mark.django_db
def test_admin_login_page():

    client = Client()

    response = client.get('/admin/login/')

    assert response.status_code == 200


@pytest.mark.django_db
def test_admin_page():

    client = Client()

    response = client.get('/admin/')

    assert response.status_code in [200, 302]


@pytest.mark.django_db
def test_not_found_page():

    client = Client()

    response = client.get('/unknown-page/')

    assert response.status_code == 404


@pytest.mark.django_db
def test_static_redirect():

    client = Client()

    response = client.get('/admin/login/')

    assert response.status_code == 200
