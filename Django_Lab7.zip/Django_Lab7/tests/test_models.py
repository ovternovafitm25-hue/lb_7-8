import pytest

from library.models import (
    Author,
    Book
)


@pytest.mark.django_db
def test_create_author(author):

    assert author.first_name == 'Taras'


@pytest.mark.django_db
def test_author_str(author):

    assert str(author) == 'Taras Shevchenko'


@pytest.mark.django_db
def test_create_book(author):

    book = Book.objects.create(
        title='Kobzar',
        isbn='1234567890123',
        pages=100,
        year=1840,
        author=author
    )

    assert book.title == 'Kobzar'


@pytest.mark.django_db
def test_default_pages(author):

    book = Book.objects.create(
        title='Test',
        isbn='9999999999999',
        year=2000,
        author=author
    )

    assert book.pages == 100


@pytest.mark.django_db
def test_update_book(author):

    book = Book.objects.create(
        title='Old',
        isbn='8888888888888',
        pages=50,
        year=2000,
        author=author
    )

    book.title = 'New'
    book.save()

    assert book.title == 'New'


@pytest.mark.parametrize(
    "pages",
    [100, 200, 300]
)
@pytest.mark.django_db
def test_book_pages(author, pages):

    book = Book.objects.create(
        title=f'Book {pages}',
        isbn=f'100000000{pages}',
        pages=pages,
        year=2000,
        author=author
    )

    assert book.pages == pages
